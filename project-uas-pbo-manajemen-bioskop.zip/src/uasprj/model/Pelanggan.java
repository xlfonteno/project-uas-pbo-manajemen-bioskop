/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uasprj.model;

/**
 *
 * @author SomethingDelicious
 */
public class Pelanggan {
    private int idPelanggan;
    private String nama;
    private String noHP;

    public Pelanggan() {}

    public Pelanggan(int idPelanggan, String nama, String noHP) {
        this.idPelanggan = idPelanggan;
        this.nama = nama;
        this.noHP = noHP;
    }

    // getter & setter
}
